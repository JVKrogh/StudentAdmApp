package com.example.studentadministration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

@SpringBootApplication
public class StudentadministrationApplication {

    public static void main(String[] args) {
        SpringApplication.run(StudentadministrationApplication.class, args);


/*
        Connection conn = null;
        try {
            String url = "jdbc:mysql://localhost:3306/students";
            conn = DriverManager.getConnection(url);

            System.out.println("Got it!");

        } catch (SQLException e) {
            throw new Error("Problem", e);
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
    } */

    }
}

