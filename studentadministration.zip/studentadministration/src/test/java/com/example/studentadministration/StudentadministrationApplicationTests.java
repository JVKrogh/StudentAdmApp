package com.example.studentadministration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentadministrationApplicationTests {

    @Test
    void contextLoads() {
    }

}
